package sk.stuba.fei.uim.oop;

import sk.stuba.fei.uim.oop.gameStart.GameStart;

public class Assignment1 {
    public static void main(String[] args) {
        new GameStart();
    }
}
