package sk.stuba.fei.uim.oop.playedPack;

public class PlayedPack {
}
